# ERP Comercial

ERP Comercial para control de ventas, prospección B2B, CRM Leads, cotizaciones y KPIs ejecutivos.

Esta versión está preparada para subirse a **GitHub** como repositorio y ejecutarse en un entorno con **PHP + SQLite**.

## Importante sobre GitHub Pages

GitHub Pages **no ejecuta PHP ni SQLite**.  
Esto significa que este proyecto puede subirse a GitHub para control de versiones, respaldo y colaboración, pero **no funcionará directamente en GitHub Pages** como aplicación con base de datos.

Para ejecutarlo necesitas una de estas opciones:

- Localmente con PHP instalado.
- XAMPP, WAMP, MAMP o Laragon.
- Hosting compatible con PHP y SQLite.
- VPS o servidor propio con PHP.
- GitHub Codespaces con PHP instalado.

## Estructura del proyecto

```text
ERP_Comercial/
├── api/
│   └── api.php
├── data/
│   └── .gitkeep
├── database/
│   └── schema.sql
├── docs/
├── public/
│   └── index.php
├── .env.example
├── .gitignore
├── .htaccess
├── index.php
├── LICENSE
└── README.md
```

## Base de datos

La base SQLite se crea automáticamente en:

```text
data/erp_comercial.sqlite
```

Ese archivo **no debe subirse a GitHub**, porque contiene la información operativa del ERP.  
Por eso está excluido en `.gitignore`.

El archivo `database/schema.sql` queda como referencia de estructura.

## Requisitos

- PHP 8.0 o superior recomendado.
- Extensión SQLite habilitada:
  - `pdo_sqlite`
  - `sqlite3`

Para verificarlo:

```bash
php -m | grep sqlite
```

En Windows con XAMPP, normalmente ya viene habilitado.

## Ejecución local rápida

Desde la carpeta raíz del proyecto:

```bash
php -S localhost:8000
```

Después abre:

```text
http://localhost:8000
```

O directamente:

```text
http://localhost:8000/public/index.php
```

## Probar la API

Abre en el navegador:

```text
http://localhost:8000/api/api.php?action=health
```

Respuesta esperada:

```json
{
  "success": true,
  "message": "API PHP funcionando correctamente.",
  "database": "data/erp_comercial.sqlite"
}
```

## Cómo subirlo a GitHub

### 1. Crear repositorio local

```bash
git init
git add .
git commit -m "Initial commit ERP Comercial"
```

### 2. Crear repositorio en GitHub

En GitHub crea un repositorio nuevo, por ejemplo:

```text
erp-comercial
```

### 3. Conectar y subir

Reemplaza `TU-USUARIO` por tu usuario u organización de GitHub:

```bash
git remote add origin https://github.com/TU-USUARIO/erp-comercial.git
git branch -M main
git push -u origin main
```

## Instalación en hosting PHP

1. Sube todos los archivos del repositorio al hosting.
2. Asegúrate de que la carpeta `data/` tenga permisos de escritura.
3. Abre el sitio en el navegador.
4. La base `data/erp_comercial.sqlite` se creará automáticamente al guardar datos.

En Linux, si necesitas permisos:

```bash
chmod 775 data
```

## Uso recomendado

1. Abre el ERP.
2. Configura el tipo de cambio USD/MN en el módulo **Configuración**.
3. Registra prospección diaria en **Prospección B2B**.
4. Los leads pueden pasar a **CRM Leads**.
5. Registra cotizaciones en **Cotizaciones**.
6. Revisa **Captura Semanal Auto** y **Dashboard Ejecutivo**.

## Seguridad

Esta versión es local/simple y no incluye login.  
Antes de usarla en internet o con varios usuarios se recomienda agregar:

- Autenticación.
- Roles y permisos.
- Backups automáticos.
- Protección CSRF.
- HTTPS.
- Bitácora de cambios por usuario.

## Respaldo de datos

Para respaldar la información, copia este archivo:

```text
data/erp_comercial.sqlite
```

También puedes respaldar el repositorio completo, pero recuerda que el `.sqlite` no se sube por defecto a GitHub.

## Restaurar respaldo

1. Detén el servidor.
2. Copia tu respaldo como:

```text
data/erp_comercial.sqlite
```

3. Vuelve a iniciar el servidor.

## Notas técnicas

El frontend guarda y carga el estado mediante:

```text
api/api.php?action=load
api/api.php?action=save
api/api.php?action=reset
```

La información del ERP se guarda como JSON dentro de SQLite para mantener flexibilidad con los módulos actuales.
