<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$action = $_GET['action'] ?? 'load';

try {
    $dataDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';

    if (!is_dir($dataDir)) {
        if (!mkdir($dataDir, 0775, true) && !is_dir($dataDir)) {
            throw new RuntimeException('No se pudo crear la carpeta data.');
        }
    }

    $dbPath = $dataDir . DIRECTORY_SEPARATOR . 'erp_comercial.sqlite';
    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    initializeDatabase($pdo);

    if ($action === 'load') {
        loadState($pdo);
    } elseif ($action === 'save') {
        saveState($pdo);
    } elseif ($action === 'reset') {
        resetState($pdo);
    } elseif ($action === 'health') {
        echo json_encode([
            'success' => true,
            'message' => 'API PHP funcionando correctamente.',
            'database' => 'data/erp_comercial.sqlite',
            'time' => date('c')
        ], JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Acción no válida.'], JSON_UNESCAPED_UNICODE);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

function initializeDatabase(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS app_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            state_json TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            description TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    ");
}

function loadState(PDO $pdo): void
{
    $stmt = $pdo->query("SELECT state_json, updated_at FROM app_state WHERE id = 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode(['success' => true, 'state' => null, 'updated_at' => null], JSON_UNESCAPED_UNICODE);
        return;
    }

    $state = json_decode($row['state_json'], true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException('La información guardada no es JSON válido.');
    }

    echo json_encode([
        'success' => true,
        'state' => $state,
        'updated_at' => $row['updated_at']
    ], JSON_UNESCAPED_UNICODE);
}

function saveState(PDO $pdo): void
{
    $raw = file_get_contents('php://input');

    if ($raw === false || trim($raw) === '') {
        throw new RuntimeException('No se recibió información para guardar.');
    }

    $decoded = json_decode($raw, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new RuntimeException('El cuerpo recibido no es JSON válido: ' . json_last_error_msg());
    }

    $normalizedJson = json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO app_state (id, state_json, created_at, updated_at)
        VALUES (1, :state_json, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(id) DO UPDATE SET
            state_json = excluded.state_json,
            updated_at = CURRENT_TIMESTAMP
    ");
    $stmt->execute([':state_json' => $normalizedJson]);

    $audit = $pdo->prepare("
        INSERT INTO audit_log (action, description)
        VALUES ('save', 'Estado del ERP guardado desde el frontend')
    ");
    $audit->execute();

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Información guardada correctamente.',
        'updated_at' => date('c')
    ], JSON_UNESCAPED_UNICODE);
}

function resetState(PDO $pdo): void
{
    $pdo->beginTransaction();

    $pdo->exec("DELETE FROM app_state WHERE id = 1");

    $audit = $pdo->prepare("
        INSERT INTO audit_log (action, description)
        VALUES ('reset', 'Estado del ERP restablecido por el usuario')
    ");
    $audit->execute();

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Base local restablecida correctamente.'], JSON_UNESCAPED_UNICODE);
}
?>