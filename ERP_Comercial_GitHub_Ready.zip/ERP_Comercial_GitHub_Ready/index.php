<?php
// Redirect root access to the ERP frontend.
header('Location: public/index.php');
exit;
?>
